<?php
/**
 * Componente: Caja Formulario Imagen.
 *
 * @package Acronyms\RAW
 * @subpackage Components
 * @since 1.0.0
 */

?>
<h2 class="big">¿QUIERES RESPUESTAS A TODAS TUS PREGUNTAS SOBRE LA SEGUNDA OPORTUNIDAD?</h2>

<span class="btn-green">COMPLETAMENTE GRATUITA</span>

<div class="grid">
	<div>
		<b>Esta guía responde a las dudas sobre el procedimiento de la  Segunda Oportunidad que nos han hecho nuestros más de 4.000 clientes.</b>

		<p>¿Qué puntos trata esta guía?</p>
		<ol>
			<li>Coste</li>
			<li>Requisitos</li>
			<li>Trámites</li>
			<li>Cuestiones generales</li>
		</ol>

		<b>¡Todas tus DUDAS sobre LSO RESUELTAS!</b>
		<script charset="utf-8" type="text/javascript" src="//js-eu1.hsforms.net/forms/embed/v2.js"></script>
		<script>
			hbspt.forms.create({
				region: "eu1",
				portalId: "25960949",
				formId: "39400740-824b-4a59-9015-54e3ffd02345"
			});
		</script>
	</div>

	<div><?php print wp_get_attachment_image( 27924, array( 495, 786 ) ); ?></div>
</div>