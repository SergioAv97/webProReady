<div class="grid">

	<div class="home">
		<p>Somos una empresa española creada por expertos en el sector financiero y jurídico.</p>
		<p class="subtitle">¿Nuestra misión?</p>
		<p class="title">Una vida libre de deudas.</p>
	</div>

	<div>
		<video autoplay="false" controls="true" controlslist="nodownload" src="/wp-content/uploads/2022/12/video-presentacion-smd.mp4"></video>
		<noscript><video autoplay="false" controls="true" controlslist="nodownload" src="/wp-content/uploads/2022/12/video-presentacion-smd.mp4"></video></noscript>
	</div>

</div>